﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06_02_20_Homework_BlogLesson_41_Thread
{
    class PrintEventArgs: EventArgs
    {
        public int Seconds { get; set; }
    }
}
